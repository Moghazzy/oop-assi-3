import java.util.ArrayList;

public class groceryList {

    private ArrayList<groceryItemOrder> groceryList ;


    public groceryList() {
        this.groceryList = new ArrayList<groceryItemOrder>(10);
    }
    public void addGroceryItem(groceryItemOrder item) {
        if (groceryList.size() < 10) {
            groceryList.add(item);
            System.out.println("Item " + item + " added to the grocery list");
        } else {
            System.out.println("You can't add more than 10 items to the grocery list");
        }

    }
    public double getTotalCost() {
        double totalCost = 0;
        for (int i = 0; i < groceryList.size(); i++) {
            totalCost += groceryList.get(i).getCost();
        }
        return totalCost;
    }

    public void printGroceryList() {
        System.out.println("You have " + groceryList.size() + " items in your grocery list");
        for (int i = 0; i < groceryList.size(); i++) {
            System.out.println((i + 1) + ". " + groceryList.get(i));
        }
    }



}