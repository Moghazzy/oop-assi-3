import java.util.ArrayList;

import java.util.Collections;
public class Main {
    public static void main(String[] args) {



        public class Main {
            public static void main(String[] args) {
                ArrayList<Integer> list = new ArrayList<>();
                list.add(1);
                list.add(2);
                list.add(9);
                list.add(10);
                list.add(5);
                list.add(8);
                int n = max(list);
                ArrayList<Integer> list2 = Sort(list);
                System.out.println(list2);
                System.out.println(n);
            }
        }
    }
}